
In order to use our malicious software, one should first follow the instructions below:
Step 1: In the victim’s device, open the directory “client”, makefile and run client with root permission. (Note that before we run the makefile, victim should modify attacker’s IP address and port in  “client.c”, which should be modified in 3 points of  “client.c” . This is to make sure victim can connect to a certain attacker’s device).

Step 2: In the attacker’s device, open the directory “server”, makefile and run server using command ./server <port>. (Note that one should make sure the server is on when try to execute client. For a restart client, attacker need to make sure server is executed before victim login the system. Then the victim’s device will automatically connect to attacker’s device) 

Step 3: After a successful connection is established, the attacker will receive a message and are able to use different command.